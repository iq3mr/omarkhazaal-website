import Container from "@/components/ui/Container";

export default function OpeningScene() {
  return (
    <section className="min-h-screen flex items-center bg-[#F8F6F1]">
      <Container>
        <div className="grid lg:grid-cols-2 items-center gap-16">

          {/* Left */}

          <div>

            <p className="text-sm tracking-[0.35em] uppercase text-[#A30000] mb-6">
              VISION
            </p>

            <h1 className="display-xl text-balance">
              تعلم...
              <br />
              كيف ترى.
            </h1>

            <p className="body-lg mt-10 max-w-xl text-neutral-600">
              أكاديمية عربية للفن والتصميم وصناعة المحتوى
              والبحث الأكاديمي.
            </p>

          </div>

          {/* Right */}

          <div className="flex justify-center">

            <div className="w-[420px] h-[420px] rounded-full border border-neutral-300 flex items-center justify-center">

              <div className="w-64 h-64 rounded-full border border-[#A30000]/40 flex items-center justify-center">

                <div className="w-24 h-24 rounded-full bg-[#A30000]" />

              </div>

            </div>

          </div>

        </div>
      </Container>
    </section>
  );
}