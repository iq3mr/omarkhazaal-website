"use client";

import Container from "../ui/Container";
import Logo from "../ui/Logo";
import { navigation } from "../../lib/navigation";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 border-b border-neutral-200/80 bg-[#F8F6F1]/80 backdrop-blur-xl">
      <Container>
        <nav className="flex h-24 items-center justify-between">

          {/* Logo */}

          <Logo />

          {/* Navigation */}

          <ul className="hidden gap-10 lg:flex">

            {navigation.map((item) => (
              <li key={item.label}>
                <a
                  href={item.href}
                  className="text-sm font-medium text-neutral-700 transition-colors duration-300 hover:text-[#A30000]"
                >
                  {item.label}
                </a>
              </li>
            ))}

          </ul>

        </nav>
      </Container>
    </header>
  );
}