import Container from "../ui/Container";

const navigation = [
  "الرئيسية",
  "الدورات",
  "الكتب",
  "المقالات",
  "دفترنا",
  "من أنا",
];

export default function Footer() {
  return (
    <footer className="border-t border-neutral-300 bg-[#F8F6F1] py-20 text-[#111111]">
      <Container>
        <div className="grid gap-16 lg:grid-cols-12">
          <div className="lg:col-span-6">
            <p className="text-xs uppercase tracking-[0.45em] text-[#A30000]">
              Omar Khazaal Academy
            </p>

            <h2 className="mt-6 text-4xl font-light leading-tight tracking-[-0.03em] md:text-5xl">
              تعلم...
              <br />
              كيف ترى.
            </h2>

            <p className="mt-8 max-w-lg leading-8 text-neutral-700">
              منصة عربية للتعلم، والبحث، وصناعة المحتوى، تهدف إلى بناء ثقافة
              بصرية معاصرة تجمع بين الفن، والتصميم، والمعرفة الأكاديمية.
            </p>
          </div>

          <div className="lg:col-span-3">
            <p className="mb-6 text-sm uppercase tracking-[0.3em] text-[#A30000]">
              Explore
            </p>

            <nav className="space-y-4">
              {navigation.map((item) => (
                <a
                  key={item}
                  href="#"
                  className="block text-neutral-700 transition-colors duration-300 hover:text-[#A30000]"
                >
                  {item}
                </a>
              ))}
            </nav>
          </div>

          <div className="lg:col-span-3">
            <p className="mb-6 text-sm uppercase tracking-[0.3em] text-[#A30000]">
              Contact
            </p>

            <div className="space-y-4 text-neutral-700">
              <p>OmarKhazaal.com</p>
              <p>info@omarkhazaal.com</p>
              <p>Basra — Iraq</p>
            </div>
          </div>
        </div>

        <div className="mt-20 flex flex-col gap-4 border-t border-neutral-300 pt-8 text-sm text-neutral-500 md:flex-row md:items-center md:justify-between">
          <p>© 2026 Omar Khazaal Academy. All Rights Reserved.</p>

          <p>Designed with simplicity.</p>
        </div>
      </Container>
    </footer>
  );
}