type ButtonProps = {
  children: React.ReactNode;
  variant?: "primary" | "secondary";
};

export default function Button({
  children,
  variant = "primary",
}: ButtonProps) {
  return (
    <button
      className={`
        inline-flex
        items-center
        justify-center
        rounded-full
        px-7
        py-3
        text-sm
        font-medium
        transition-all
        duration-300

        ${
          variant === "primary"
            ? "bg-[#111111] text-white hover:bg-[#A30000]"
            : "border border-gray-300 bg-white hover:border-[#A30000] hover:text-[#A30000]"
        }
      `}
    >
      {children}
    </button>
  );
}