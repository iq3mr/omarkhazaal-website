type BadgeProps = {
  children: React.ReactNode;
};

export default function Badge({ children }: BadgeProps) {
  return (
    <span className="inline-flex items-center rounded-full border border-red-700/20 bg-red-700/5 px-3 py-1 text-xs font-medium tracking-wide text-red-700">
      {children}
    </span>
  );
}