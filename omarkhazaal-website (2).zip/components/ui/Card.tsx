type CardProps = {
  children: React.ReactNode;
};

export default function Card({ children }: CardProps) {
  return (
    <article className="rounded-3xl border border-gray-200 bg-white p-8 transition duration-500 hover:-translate-y-1 hover:shadow-xl">
      {children}
    </article>
  );
}