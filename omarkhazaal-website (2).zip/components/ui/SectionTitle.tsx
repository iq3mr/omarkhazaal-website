type SectionTitleProps = {
  label?: string;
  title: string;
  description?: string;
};

export default function SectionTitle({
  label,
  title,
  description,
}: SectionTitleProps) {
  return (
    <div className="max-w-3xl">

      {label && (
        <p className="mb-3 text-sm font-semibold uppercase tracking-[0.25em] text-red-700">
          {label}
        </p>
      )}

      <h2 className="text-5xl font-black leading-tight tracking-tight text-black">
        {title}
      </h2>

      {description && (
        <p className="mt-6 text-lg leading-8 text-gray-600">
          {description}
        </p>
      )}

    </div>
  );
}