export default function Logo() {
  return (
    <div className="select-none">

      <h2 className="text-3xl font-black tracking-tight">
        عمر خزعل
      </h2>

      <p className="mt-1 text-xs tracking-[0.45em] text-neutral-500 uppercase">
        Omar Khazaal Academy
      </p>

    </div>
  );
}