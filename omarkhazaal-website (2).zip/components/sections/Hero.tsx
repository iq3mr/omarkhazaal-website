import Container from "../ui/Container";

export default function Hero() {
  return (
    <section className="relative flex min-h-screen items-center overflow-hidden bg-[#F8F6F1] text-[#111111]">
      <Container>
        <div className="grid gap-20 lg:grid-cols-12 lg:items-center">
          {/* Left */}

          <div className="lg:col-span-7">
            <p className="mb-8 text-xs uppercase tracking-[0.5em] text-[#A30000]">
              Omar Khazaal Academy
            </p>

            <h1 className="max-w-4xl text-5xl font-light leading-[1.08] tracking-[-0.05em] md:text-7xl xl:text-8xl">
              تعلم...
              <br />
              كيف ترى.
            </h1>

            <p className="mt-12 max-w-2xl text-lg leading-9 text-neutral-700">
              منصة عربية متخصصة في تعليم الفن، والتصميم، وصناعة المحتوى،
              والبحث الأكاديمي، تجمع بين المعرفة والخبرة العملية ضمن تجربة
              تعليمية هادئة، معاصرة، وبهوية بصرية متحفية.
            </p>

            <div className="mt-16 flex flex-wrap gap-5">
              <button className="bg-[#A30000] px-8 py-4 text-sm tracking-[0.2em] text-white transition hover:opacity-90">
                ابدأ التعلم
              </button>

              <button className="border border-[#111111] px-8 py-4 text-sm tracking-[0.2em] transition hover:border-[#A30000] hover:text-[#A30000]">
                اكتشف الأكاديمية
              </button>
            </div>
          </div>

          {/* Right */}

          <div className="relative lg:col-span-5">
            <div className="aspect-[4/5] border border-neutral-300 bg-white p-8">
              <div className="flex h-full items-center justify-center border border-dashed border-[#A30000]/40">
                <div className="text-center">
                  <p className="text-xs uppercase tracking-[0.4em] text-[#A30000]">
                    Featured
                  </p>

                  <h3 className="mt-6 text-3xl font-light">
                    مكتوب العين
                  </h3>

                  <p className="mt-6 leading-8 text-neutral-600">
                    أول إصدارات أكاديمية عمر خزعل في التربية الفنية
                    والثقافة البصرية.
                  </p>
                </div>
              </div>
            </div>

            <div className="absolute -left-8 -bottom-8 h-32 w-32 rounded-full border border-[#A30000]/25" />

            <div className="absolute -right-6 -top-6 h-20 w-20 rounded-full bg-[#A30000]" />
          </div>
        </div>
      </Container>
    </section>
  );
}