import Container from "../components/ui/Container";

export default function Manifesto() {
  return (
    <section className="bg-[#F8F6F1] py-36 text-[#111111]">
      <Container>
        <div className="mx-auto max-w-5xl">
          <p className="mb-6 text-xs uppercase tracking-[0.45em] text-[#A30000]">
            Manifesto
          </p>

          <h2 className="text-4xl leading-[1.35] font-light tracking-[-0.03em] md:text-6xl">
            الفن ليس موهبةً فقط...
            <br />
            بل طريقةٌ في رؤية العالم.
          </h2>

          <div className="mt-16 grid gap-10 md:grid-cols-2">
            <p className="text-lg leading-9 text-neutral-700">
              في أكاديمية عمر خزعل نؤمن أن التعلم الحقيقي يبدأ عندما يتغير
              منظورك، لا عندما تحفظ المعلومات. لذلك صُممت هذه المنصة لتكون
              مساحة تجمع بين المعرفة الأكاديمية والخبرة العملية، وتقدمها بلغة
              عربية معاصرة وهوية بصرية هادئة.
            </p>

            <p className="text-lg leading-9 text-neutral-700">
              هنا ستجد دورات، وكتباً، ومقالات، وأبحاثاً، ومحتوى معرفياً يساعدك
              على تطوير عينك الفنية قبل أدواتك، لتصبح أكثر قدرة على التحليل،
              والإبداع، وصناعة أعمال تحمل قيمة حقيقية.
            </p>
          </div>

          <div className="mt-24 grid gap-8 border-t border-neutral-300 pt-10 md:grid-cols-3">
            <div>
              <p className="text-sm uppercase tracking-[0.3em] text-[#A30000]">
                Learn
              </p>

              <p className="mt-3 text-neutral-700 leading-8">
                تعلّم بأسلوب أكاديمي مبسط يعتمد على الفهم والتطبيق.
              </p>
            </div>

            <div>
              <p className="text-sm uppercase tracking-[0.3em] text-[#A30000]">
                Think
              </p>

              <p className="mt-3 text-neutral-700 leading-8">
                طوّر قدرتك على التحليل والنقد وبناء رؤية بصرية مستقلة.
              </p>
            </div>

            <div>
              <p className="text-sm uppercase tracking-[0.3em] text-[#A30000]">
                Create
              </p>

              <p className="mt-3 text-neutral-700 leading-8">
                حوّل المعرفة إلى مشاريع وأعمال ومحتوى يترك أثراً.
              </p>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}