import Container from "@/components/ui/Container";

export default function AboutOmar() {
  return (
    <section className="bg-[#F8F6F1] py-36 text-[#111111]">
      <Container>
        <div className="grid gap-20 lg:grid-cols-12 lg:items-start">
          {/* Left */}

          <div className="lg:col-span-4">
            <p className="mb-6 text-xs uppercase tracking-[0.45em] text-[#A30000]">
              About
            </p>

            <h2 className="text-4xl font-light leading-tight tracking-[-0.03em] md:text-5xl">
              عمر خزعل
            </h2>

            <p className="mt-4 text-sm uppercase tracking-[0.3em] text-neutral-500">
              Omar Khazaal
            </p>
          </div>

          {/* Right */}

          <div className="lg:col-span-8">
            <p className="max-w-3xl text-xl leading-10 text-neutral-700">
              فنان تشكيلي، ومدرس تربية فنية، وباحث أكاديمي، وصانع محتوى.
              أؤمن بأن التعليم الجيد لا يقتصر على نقل المعلومات، بل يبدأ
              ببناء طريقة جديدة في التفكير والرؤية. لذلك جاءت أكاديمية عمر
              خزعل لتكون منصة عربية تقدم المعرفة بأسلوب بصري هادئ، يجمع بين
              الخبرة العملية والأساس الأكاديمي.
            </p>

            <div className="mt-20 grid gap-10 border-t border-neutral-300 pt-10 md:grid-cols-3">
              <div>
                <p className="text-5xl font-light text-[#A30000]">10+</p>

                <p className="mt-3 text-sm uppercase tracking-[0.25em] text-neutral-500">
                  Years
                </p>

                <p className="mt-4 leading-8 text-neutral-700">
                  سنوات من العمل في التعليم والفنون وصناعة المحتوى.
                </p>
              </div>

              <div>
                <p className="text-5xl font-light text-[#A30000]">100+</p>

                <p className="mt-3 text-sm uppercase tracking-[0.25em] text-neutral-500">
                  Articles
                </p>

                <p className="mt-4 leading-8 text-neutral-700">
                  مقالات وأبحاث ومحتوى معرفي في الفن والتصميم والثقافة.
                </p>
              </div>

              <div>
                <p className="text-5xl font-light text-[#A30000]">∞</p>

                <p className="mt-3 text-sm uppercase tracking-[0.25em] text-neutral-500">
                  Vision
                </p>

                <p className="mt-4 leading-8 text-neutral-700">
                  بناء مرجع عربي معاصر يطور الثقافة البصرية ويجعل التعلم أكثر
                  عمقاً وإلهاماً.
                </p>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}