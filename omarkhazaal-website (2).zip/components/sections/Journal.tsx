import Container from "../components/ui/Container";

const articles = [
  {
    category: "مقال",
    title: "لماذا نتعلم الفن؟",
    excerpt:
      "رحلة في أهمية التربية الفنية ودورها في تشكيل طريقة التفكير، وليس فقط تعلم الرسم.",
  },
  {
    category: "دفترنا",
    title: "كيف تبدأ مشروعاً إبداعياً؟",
    excerpt:
      "مجموعة أفكار وتجارب عملية تساعدك على تحويل الفكرة إلى مشروع قابل للنمو.",
  },
  {
    category: "بحث",
    title: "الثقافة البصرية في العصر الرقمي",
    excerpt:
      "قراءة في أثر المنصات الرقمية على الذائقة البصرية والتعليم والإبداع.",
  },
];

export default function Journal() {
  return (
    <section className="bg-[#F8F6F1] py-36 text-[#111111]">
      <Container>
        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="mb-6 text-xs uppercase tracking-[0.45em] text-[#A30000]">
              Journal
            </p>

            <h2 className="text-4xl font-light tracking-[-0.03em] md:text-5xl">
              المقالات ودفترنا
            </h2>
          </div>

          <p className="max-w-md leading-8 text-neutral-600">
            مساحة تُنشر فيها المقالات، والأبحاث، والتجارب، وكل ما يساعد على
            بناء ثقافة بصرية عربية معاصرة.
          </p>
        </div>

        <div className="mt-20 grid gap-8 lg:grid-cols-3">
          {articles.map((article) => (
            <article
              key={article.title}
              className="flex h-full flex-col border-t border-neutral-300 pt-8 transition-all duration-300 hover:border-[#A30000]"
            >
              <p className="text-xs uppercase tracking-[0.35em] text-[#A30000]">
                {article.category}
              </p>

              <h3 className="mt-5 text-2xl font-light leading-tight">
                {article.title}
              </h3>

              <p className="mt-6 flex-1 leading-8 text-neutral-700">
                {article.excerpt}
              </p>

              <div className="mt-10">
                <span className="text-sm uppercase tracking-[0.25em] text-[#A30000]">
                  Read More
                </span>
              </div>
            </article>
          ))}
        </div>
      </Container>
    </section>
  );
}