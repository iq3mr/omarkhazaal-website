import Container from "../components/ui/Container";

const courses = [
  {
    number: "01",
    title: "أساسيات الفن التشكيلي",
    description:
      "مدخل لفهم عناصر العمل الفني، المبادئ الجمالية، وبناء الثقافة البصرية.",
  },
  {
    number: "02",
    title: "التصميم وصناعة الهوية",
    description:
      "تعلم التفكير التصميمي وبناء هويات بصرية معاصرة للمشاريع والأفراد.",
  },
  {
    number: "03",
    title: "صناعة المحتوى",
    description:
      "من الفكرة وحتى النشر، مع التركيز على المحتوى البصري والتعليم الرقمي.",
  },
];

export default function Courses() {
  return (
    <section className="bg-[#F8F6F1] py-36 text-[#111111]">
      <Container>
        <div className="flex items-end justify-between gap-10">
          <div>
            <p className="mb-6 text-xs uppercase tracking-[0.45em] text-[#A30000]">
              Courses
            </p>

            <h2 className="text-4xl font-light tracking-[-0.03em] md:text-5xl">
              الدورات
            </h2>
          </div>

          <p className="hidden max-w-md text-right leading-8 text-neutral-600 lg:block">
            دورات عملية وأكاديمية صُممت لبناء المعرفة والمهارة معاً.
          </p>
        </div>

        <div className="mt-20 border-t border-neutral-300">
          {courses.map((course) => (
            <article
              key={course.number}
              className="grid gap-8 border-b border-neutral-300 py-10 transition-colors duration-300 hover:bg-black/5 md:grid-cols-12 md:items-center"
            >
              <div className="md:col-span-2">
                <span className="text-sm tracking-[0.35em] text-[#A30000]">
                  {course.number}
                </span>
              </div>

              <div className="md:col-span-4">
                <h3 className="text-2xl font-light">{course.title}</h3>
              </div>

              <div className="md:col-span-6">
                <p className="leading-8 text-neutral-700">
                  {course.description}
                </p>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-16">
          <button
            className="border border-[#A30000] px-8 py-4 text-sm uppercase tracking-[0.25em] text-[#A30000] transition-colors duration-300 hover:bg-[#A30000] hover:text-white"
          >
            عرض جميع الدورات
          </button>
        </div>
      </Container>
    </section>
  );
}