import Container from "../components/ui/Container";

export default function OpeningScene() {
  return (
    <section className="min-h-screen flex items-center bg-[#F8F6F1] text-[#111111]">
      <Container>
        <div className="grid gap-20 lg:grid-cols-2 lg:items-center">
          {/* Content */}

          <div className="max-w-2xl">
            <p className="mb-8 text-xs font-medium uppercase tracking-[0.55em] text-[#A30000]">
              Omar Khazaal Academy
            </p>

            <h1 className="text-5xl font-light leading-[1.15] tracking-[-0.04em] md:text-7xl">
              تعلم...
              <br />
              كيف ترى.
            </h1>

            <p className="mt-12 max-w-xl text-lg leading-9 text-neutral-700">
              منصة عربية متخصصة في تعليم الفن، والتصميم، وصناعة المحتوى،
              والبحث الأكاديمي، تجمع الخبرة العملية مع المعرفة بأسلوب بصري
              هادئ يركز على جودة الفكرة قبل كثرة التفاصيل.
            </p>

            <div className="mt-16 flex flex-wrap gap-8 text-sm tracking-[0.25em] uppercase text-neutral-500">
              <span>Courses</span>
              <span>Books</span>
              <span>Journal</span>
              <span>Research</span>
            </div>
          </div>

          {/* Visual */}

          <div className="flex items-center justify-center">
            <div className="relative flex h-[520px] w-[520px] items-center justify-center rounded-full border border-neutral-300">
              <div className="absolute h-[380px] w-[380px] rounded-full border border-[#A30000]/30" />

              <div className="absolute h-[220px] w-[220px] rounded-full border border-[#A30000]/40" />

              <div className="h-20 w-20 rounded-full bg-[#A30000]" />
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}