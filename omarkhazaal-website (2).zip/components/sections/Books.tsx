import Container from "../ui/Container";

const books = [
  {
    year: "2026",
    title: "مكتوب العين",
    category: "كتاب",
    description:
      "كتاب يبحث في التربية الفنية والثقافة البصرية، ويقدم رؤية معاصرة لتعليم الفن باللغة العربية.",
  },
  {
    year: "Soon",
    title: "سلسلة أكاديمية عمر خزعل",
    category: "إصدارات",
    description:
      "مجموعة من الكتب والأدلة التعليمية التي تغطي الفن، والتصميم، وصناعة المحتوى بأسلوب عملي وأكاديمي.",
  },
];

export default function Books() {
  return (
    <section className="bg-[#F8F6F1] py-36 text-[#111111]">
      <Container>
        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="mb-6 text-xs uppercase tracking-[0.45em] text-[#A30000]">
              Books
            </p>

            <h2 className="text-4xl font-light tracking-[-0.03em] md:text-5xl">
              الكتب
            </h2>
          </div>

          <p className="max-w-md leading-8 text-neutral-600">
            المعرفة التي تبقى ليست في الفيديو فقط، بل في الكتب التي يمكن
            الرجوع إليها مرارًا.
          </p>
        </div>

        <div className="mt-20 grid gap-8 lg:grid-cols-2">
          {books.map((book) => (
            <article
              key={book.title}
              className="flex h-full flex-col justify-between border border-neutral-300 p-10 transition-all duration-300 hover:-translate-y-1 hover:border-[#A30000]"
            >
              <div>
                <p className="text-xs uppercase tracking-[0.35em] text-[#A30000]">
                  {book.year}
                </p>

                <h3 className="mt-6 text-3xl font-light">
                  {book.title}
                </h3>

                <p className="mt-2 text-sm uppercase tracking-[0.25em] text-neutral-500">
                  {book.category}
                </p>

                <p className="mt-8 leading-8 text-neutral-700">
                  {book.description}
                </p>
              </div>

              <div className="mt-12 border-t border-neutral-200 pt-6">
                <span className="text-sm uppercase tracking-[0.25em] text-[#A30000]">
                  Discover
                </span>
              </div>
            </article>
          ))}
        </div>
      </Container>
    </section>
  );
}