export const navigation = [
  {
    label: "الرئيسية",
    href: "/",
  },
  {
    label: "المجلة",
    href: "#",
  },
  {
    label: "الدورات",
    href: "#",
  },
  {
    label: "المكتبة",
    href: "#",
  },
  {
    label: "دفترنا",
    href: "#",
  },
  {
    label: "عن عمر",
    href: "#",
  },
];