export const site = {
  title: "أكاديمية عمر خزعل",
  url: "https://omarkhazaal.com",
};