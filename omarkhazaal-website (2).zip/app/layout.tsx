import "./globals.css";

import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "أكاديمية عمر خزعل",
  description: "الفن، التصميم، صناعة المحتوى، والبحث الأكاديمي",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl">
      <body>{children}</body>
    </html>
  );
}