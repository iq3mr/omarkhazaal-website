import Hero from "../components/sections/Hero";
import OpeningScene from "../components/sections/OpeningScene";
import Manifesto from "../components/sections/Manifesto";
import AboutOmar from "../components/sections/AboutOmar";
import Courses from "../components/sections/Courses";
import Books from "../components/sections/Books";
import Journal from "../components/sections/Journal";

export default function HomePage() {
  return (
    <>
      <Hero />
      <OpeningScene />
      <Manifesto />
      <AboutOmar />
      <Courses />
      <Books />
      <Journal />
    </>
  );
}